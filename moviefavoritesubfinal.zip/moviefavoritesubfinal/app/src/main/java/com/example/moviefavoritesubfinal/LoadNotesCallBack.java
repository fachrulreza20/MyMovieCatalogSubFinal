package com.example.moviefavoritesubfinal;

import android.database.Cursor;

public interface LoadNotesCallBack {
    public void postExecute(Cursor cursor);
}
