package com.example.moviefavoritesubfinal.helper;

import android.database.Cursor;

import com.example.moviefavoritesubfinal.entity.TVShow;

import java.util.ArrayList;

import static com.example.moviefavoritesubfinal.database.DatabaseContractTVS.FavoritColumns.DESCRIPTION;
import static com.example.moviefavoritesubfinal.database.DatabaseContractTVS.FavoritColumns.IDFAV;
import static com.example.moviefavoritesubfinal.database.DatabaseContractTVS.FavoritColumns.PHOTO_PATH;
import static com.example.moviefavoritesubfinal.database.DatabaseContractTVS.FavoritColumns.RELEASE_DATE;
import static com.example.moviefavoritesubfinal.database.DatabaseContractTVS.FavoritColumns.TITLE;

public class MappingHelperTVS {

    public static ArrayList<TVShow> mapCursorToArrayListTVS(Cursor notesCursor) {
        ArrayList<TVShow> notesList = new ArrayList<>();
        while (notesCursor.moveToNext()) {
            int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(IDFAV));
            String title = notesCursor.getString(notesCursor.getColumnIndexOrThrow(TITLE));
            String description = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DESCRIPTION));
            String date = notesCursor.getString(notesCursor.getColumnIndexOrThrow(RELEASE_DATE));
            String photo = notesCursor.getString(notesCursor.getColumnIndexOrThrow(PHOTO_PATH));
            notesList.add(new TVShow(id, title, description, date, photo));
        }
        return notesList;
    }
}